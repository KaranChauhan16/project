
package com.example.hostel.service;

import com.example.hostel.model.Allotment;
import com.example.hostel.model.Room;
import com.example.hostel.repository.AllotmentRepository;
import com.example.hostel.repository.RoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AllotmentService {
    @Autowired
    private AllotmentRepository allotmentRepository;
    @Autowired
    private RoomRepository roomRepository;

    public List<Allotment> getAllAllotments() {
        return allotmentRepository.findAll();
    }

    public Allotment saveAllotment(Allotment allotment) {
        Room room = allotment.getRoom();
        if (room.getOccupied() < room.getCapacity()) {
            room.setOccupied(room.getOccupied() + 1);
            roomRepository.save(room);
            return allotmentRepository.save(allotment);
        }
        return null;
    }
}
