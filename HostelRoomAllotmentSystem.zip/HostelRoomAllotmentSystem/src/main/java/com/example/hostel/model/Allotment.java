
package com.example.hostel.model;

import jakarta.persistence.*;
import java.util.Date;

@Entity
public class Allotment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne
    private Student student;

    @ManyToOne
    private Room room;

    private Date allotmentDate;

    // Getters and setters
}
