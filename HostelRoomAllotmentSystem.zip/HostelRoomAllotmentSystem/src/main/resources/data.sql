
INSERT INTO student (name, roll_number, department, year) VALUES
('Alice', '101', 'CSE', 2),
('Bob', '102', 'ECE', 1);

INSERT INTO room (room_number, type, capacity, occupied) VALUES
('A1', 'Single', 1, 0),
('B1', 'Double', 2, 1);
